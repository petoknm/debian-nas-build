#!/bin/sh

cd `dirname $0`

apt-get install -y i2c-tools mtd-utils

dpkg -i linux-bsp-*_*_*.deb

cd - > /dev/null

